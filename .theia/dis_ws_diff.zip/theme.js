"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.themeService = void 0;
var data_1 = __importDefault(require("@smartface/native/global/data"));
var application_1 = __importDefault(require("@smartface/native/application"));
var settings_json_1 = require("settings.json");
var styling_context_1 = require("@smartface/styling-context");
var themeConfig = settings_json_1.config.theme;
var currentTheme = data_1.default.getStringVariable('currentTheme') || themeConfig.currentTheme;
var themeSources = themeConfig.themes.map(function (name) { return ({
    name: name,
    rawStyles: require("./generated/themes/".concat(name)),
    isDefault: currentTheme === name
}); });
exports.themeService = new styling_context_1.ThemeService(themeSources);
application_1.default['theme'] = styling_context_1.ThemeService.instance;
//# sourceMappingURL=theme.js.map