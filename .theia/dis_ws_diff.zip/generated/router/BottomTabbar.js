"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var styling_context_1 = require("@smartface/styling-context");
var router_1 = require("@smartface/router");
var tabbaritem_1 = __importDefault(require("@smartface/native/ui/tabbaritem"));
var createRenderer_1 = __importDefault(require("@smartface/router/lib/native/createRenderer"));
var $BottomTabbar = /** @class */ (function (_super) {
    __extends($BottomTabbar, _super);
    function $BottomTabbar(props) {
        return _super.call(this, __assign({ renderer: (0, createRenderer_1.default)(), homeRoute: 0, tabbarParams: function () {
                var style = styling_context_1.ThemeService.instance.getNativeStyle('.sf-bottomtabbar .backgroundTest');
                console.log(style.itemColor, ' itemColor');
                return {
                    itemColor: style.itemColor,
                    ios: style.ios,
                    backgroundColor: style.backgroundColor
                };
            } }, props)) || this;
    }
    $BottomTabbar.$$styleContext = {
        classNames: '.sf-bottomtabbar .backgroundTest',
        defaultClassNames: ' .default_bottomTabbar',
        userProps: {}
    };
    return $BottomTabbar;
}(router_1.BottomTabBarRouter));
var $BottomTabbar$$TabBarItem2 = /** @class */ (function (_super) {
    __extends($BottomTabbar$$TabBarItem2, _super);
    function $BottomTabbar$$TabBarItem2(props) {
        var _this = _super.call(this, { title: 'facebook' }) || this;
        _this.testId = '___library___BottomTabbar_TabBarItem2';
        return _this;
    }
    $BottomTabbar$$TabBarItem2.$$styleContext = {
        classNames: ' .sf-tabbaritem .tt',
        defaultClassNames: '.default_common .default_tabBarItem',
        userProps: {}
    };
    return $BottomTabbar$$TabBarItem2;
}((0, styling_context_1.styleableComponentMixin)(tabbaritem_1.default)));
var $BottomTabbar$$TabBarItem1 = /** @class */ (function (_super) {
    __extends($BottomTabbar$$TabBarItem1, _super);
    function $BottomTabbar$$TabBarItem1(props) {
        var _this = _super.call(this, { title: 'Twitter' }) || this;
        _this.testId = '___library___BottomTabbar_TabBarItem1';
        return _this;
    }
    $BottomTabbar$$TabBarItem1.$$styleContext = {
        classNames: '.sf-tabbaritem .twitter',
        defaultClassNames: '.default_common .default_tabBarItem',
        userProps: {}
    };
    return $BottomTabbar$$TabBarItem1;
}((0, styling_context_1.styleableComponentMixin)(tabbaritem_1.default)));
var $BottomTabbar$$TabBarItem3 = /** @class */ (function (_super) {
    __extends($BottomTabbar$$TabBarItem3, _super);
    function $BottomTabbar$$TabBarItem3(props) {
        var _this = _super.call(this, { title: 'ssed' }) || this;
        _this.testId = '___library___BottomTabbar_TabBarItem3';
        return _this;
    }
    $BottomTabbar$$TabBarItem3.$$styleContext = {
        classNames: '.sf-tabbaritem .instagram',
        defaultClassNames: '.default_common .default_tabBarItem',
        userProps: {}
    };
    return $BottomTabbar$$TabBarItem3;
}((0, styling_context_1.styleableComponentMixin)(tabbaritem_1.default)));
var $BottomTabbar$$TabBarItem4 = /** @class */ (function (_super) {
    __extends($BottomTabbar$$TabBarItem4, _super);
    function $BottomTabbar$$TabBarItem4(props) {
        var _this = _super.call(this, { title: '0 ' }) || this;
        _this.testId = '___library___BottomTabbar_TabBarItem4';
        return _this;
    }
    $BottomTabbar$$TabBarItem4.$$styleContext = {
        classNames: '.sf-tabbaritem',
        defaultClassNames: '.default_common .default_tabBarItem',
        userProps: {}
    };
    return $BottomTabbar$$TabBarItem4;
}((0, styling_context_1.styleableComponentMixin)(tabbaritem_1.default)));
var $BottomTabbar$$TabBarItem5 = /** @class */ (function (_super) {
    __extends($BottomTabbar$$TabBarItem5, _super);
    function $BottomTabbar$$TabBarItem5(props) {
        var _this = _super.call(this, props) || this;
        _this.testId = '___library___BottomTabbar_TabBarItem5';
        return _this;
    }
    $BottomTabbar$$TabBarItem5.$$styleContext = {
        classNames: '.sf-tabbaritem',
        defaultClassNames: '.default_common .default_tabBarItem',
        userProps: {}
    };
    return $BottomTabbar$$TabBarItem5;
}((0, styling_context_1.styleableComponentMixin)(tabbaritem_1.default)));
var BottomTabbarRouterHelper = /** @class */ (function () {
    function BottomTabbarRouterHelper(props) {
        this._children = {};
        var items = [
            this.addTabbarItem(new $BottomTabbar$$TabBarItem2(), 'tabBarItem2'),
            this.addTabbarItem(new $BottomTabbar$$TabBarItem1(), 'tabBarItem1'),
            this.addTabbarItem(new $BottomTabbar$$TabBarItem3(), 'tabBarItem3'),
            this.addTabbarItem(new $BottomTabbar$$TabBarItem4(), 'tabBarItem4'),
            this.addTabbarItem(new $BottomTabbar$$TabBarItem5(), 'tabBarItem5')
        ];
        this.bottomTabbarRouter = new $BottomTabbar(__assign({ items: items }, props));
        styling_context_1.ThemeService.instance.addGlobalComponent(this, 'bottomTabbar');
    }
    Object.defineProperty(BottomTabbarRouterHelper.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    BottomTabbarRouterHelper.prototype.addTabbarItem = function (item, name) {
        this._children[name] = item;
        return item;
    };
    return BottomTabbarRouterHelper;
}());
exports.default = BottomTabbarRouterHelper;
//# sourceMappingURL=BottomTabbar.js.map