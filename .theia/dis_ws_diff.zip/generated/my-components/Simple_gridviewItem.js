"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var styling_context_1 = require("@smartface/styling-context");
var gridviewitem_1 = __importDefault(require("@smartface/native/ui/gridviewitem"));
var imageview_1 = __importDefault(require("@smartface/native/ui/imageview"));
var label_1 = __importDefault(require("@smartface/native/ui/label"));
var $Simple_gridviewItem = /** @class */ (function (_super) {
    __extends($Simple_gridviewItem, _super);
    function $Simple_gridviewItem(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $Simple_gridviewItem$$ImgPreview(), 'imgPreview');
        _this.addChildByName(new $Simple_gridviewItem$$LblTitle(), 'lblTitle');
        _this.addChildByName(new $Simple_gridviewItem$$LblSubtitle(), 'lblSubtitle');
        _this.imgPreview = _this.children.imgPreview;
        _this.lblTitle = _this.children.lblTitle;
        _this.lblSubtitle = _this.children.lblSubtitle;
        _this.testId = '___library___Simple_gridviewItem';
        return _this;
    }
    Object.defineProperty($Simple_gridviewItem.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $Simple_gridviewItem.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $Simple_gridviewItem.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            _super.prototype.addChild.call(this, child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    $Simple_gridviewItem.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $Simple_gridviewItem.$$styleContext = {
        classNames: '.sf-gridViewItem .simple-gridviewItem',
        defaultClassNames: '.default_common .default_gridViewItem',
        userProps: { height: 227 }
    };
    return $Simple_gridviewItem;
}((0, styling_context_1.styleableContainerComponentMixin)(gridviewitem_1.default)));
exports.default = $Simple_gridviewItem;
var $Simple_gridviewItem$$ImgPreview = /** @class */ (function (_super) {
    __extends($Simple_gridviewItem$$ImgPreview, _super);
    function $Simple_gridviewItem$$ImgPreview(props) {
        var _this = _super.call(this, props) || this;
        _this.testId = '___library___Simple_gridviewItem_ImgPreview';
        return _this;
    }
    $Simple_gridviewItem$$ImgPreview.$$styleContext = {
        classNames: '.sf-imageView .simple-gridviewItem-preview',
        defaultClassNames: '.default_common .default_imageView',
        userProps: {}
    };
    return $Simple_gridviewItem$$ImgPreview;
}((0, styling_context_1.styleableComponentMixin)(imageview_1.default)));
var $Simple_gridviewItem$$LblTitle = /** @class */ (function (_super) {
    __extends($Simple_gridviewItem$$LblTitle, _super);
    function $Simple_gridviewItem$$LblTitle(props) {
        var _this = _super.call(this, { text: 'Grid Title Here' }) || this;
        _this.testId = '___library___Simple_gridviewItem_LblTitle';
        return _this;
    }
    $Simple_gridviewItem$$LblTitle.$$styleContext = {
        classNames: '.sf-label .simple-gridviewItem-title',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $Simple_gridviewItem$$LblTitle;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $Simple_gridviewItem$$LblSubtitle = /** @class */ (function (_super) {
    __extends($Simple_gridviewItem$$LblSubtitle, _super);
    function $Simple_gridviewItem$$LblSubtitle(props) {
        var _this = _super.call(this, { text: 'Grid subtitle here' }) || this;
        _this.testId = '___library___Simple_gridviewItem_LblSubtitle';
        return _this;
    }
    $Simple_gridviewItem$$LblSubtitle.$$styleContext = {
        classNames: '.sf-label .simple-gridviewItem-subtitle',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $Simple_gridviewItem$$LblSubtitle;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
//# sourceMappingURL=Simple_gridviewItem.js.map