"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//------------------------------------------------------------------------------
//
//     This code was auto generated.
//
//     Manual changes to this file may cause unexpected behavior in your application.
//     Manual changes to this file will be overwritten if the code is regenerated.
//
//------------------------------------------------------------------------------
var styling_context_1 = require("@smartface/styling-context");
var page_1 = __importDefault(require("@smartface/native/ui/page"));
var button_1 = __importDefault(require("@smartface/native/ui/button"));
var $Page3 = /** @class */ (function (_super) {
    __extends($Page3, _super);
    function $Page3(props) {
        var _this = _super.call(this, Object.assign({}, props)) || this;
        _this._children = {};
        _this.ios && (_this.ios.safeAreaLayoutMode = true);
        _this._children.statusBar = _this.statusBar || {};
        _this._children.headerBar = _this.headerBar || {};
        _this.addChildByName(new $BtnDismiss(), 'btnDismiss');
        _this.btnDismiss = _this.children.btnDismiss;
        _this.applyTestIDs('_Page3');
        return _this;
    }
    Object.defineProperty($Page3.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    $Page3.prototype.getName = function () {
        return 'Page3';
    };
    $Page3.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
        this.headerBar.title = 'Modal Page';
    };
    $Page3.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    /**
     * @deprecated The method should not be used
     */
    $Page3.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $Page3.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $Page3.prototype.removeChild = function (child) {
        var _this = this;
        _super.prototype.removeChild.call(this, child);
        Object.keys(this._children).forEach(function (name) {
            if (child === _this._children[name])
                delete _this._children[name];
        });
    };
    $Page3.prototype.removeChildren = function () {
        this._children = { statusBar: this._children.statusBar, headerBar: this._children.headerBar };
        _super.prototype.removeChildren.call(this);
    };
    $Page3.$$styleContext = {
        classNames: '.sf-page #page1 #page3',
        defaultClassNames: ' .default_page',
        userProps: {},
        statusBar: {
            classNames: '.sf-statusBar',
            defaultClassNames: ' .default_statusBar',
            userProps: {}
        },
        headerBar: {
            classNames: '.sf-headerBar',
            defaultClassNames: ' .default_headerBar',
            userProps: {}
        }
    };
    return $Page3;
}((0, styling_context_1.styleablePageMixin)(page_1.default)));
exports.default = $Page3;
var $BtnDismiss = /** @class */ (function (_super) {
    __extends($BtnDismiss, _super);
    function $BtnDismiss(props) {
        return _super.call(this, { text: 'Dismiss' }) || this;
    }
    $BtnDismiss.$$styleContext = {
        classNames: '.sf-button #page3-btnGoBack',
        defaultClassNames: '.default_common .default_button',
        userProps: { usePageVariable: true }
    };
    return $BtnDismiss;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
//# sourceMappingURL=index.js.map