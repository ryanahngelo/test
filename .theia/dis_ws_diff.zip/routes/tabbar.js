"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@smartface/router");
var BottomTabbar_1 = __importDefault(require("generated/router/BottomTabbar"));
var page1_1 = __importDefault(require("pages/page1"));
var page2_1 = __importDefault(require("pages/page2"));
var page3_1 = __importDefault(require("pages/page3"));
var $BottomTabBar = /** @class */ (function (_super) {
    __extends($BottomTabBar, _super);
    function $BottomTabBar() {
        return _super.call(this, {
            path: '/btb',
            to: '/btb/tab1/page1',
            routes: [
                // tab1
                router_1.NativeStackRouter.of({
                    path: '/btb/tab1',
                    to: '/btb/tab1/page1',
                    routes: [
                        router_1.Route.of({
                            path: "/btb/tab1/page1",
                            build: function (router, route) {
                                return new page1_1.default(router, route);
                            },
                            headerBarParams: function () { return ({
                                visible: true
                            }); }
                        })
                    ]
                }),
                router_1.NativeStackRouter.of({
                    path: '/btb/tab2',
                    to: '/btb/tab2/page2',
                    routes: [
                        router_1.Route.of({
                            path: "/btb/tab2/page2",
                            build: function (router, route) {
                                return new page2_1.default(router, route);
                            },
                            headerBarParams: function () { return ({
                                visible: true
                            }); }
                        })
                    ]
                }),
                router_1.NativeStackRouter.of({
                    path: '/btb/tab3',
                    to: '/btb/tab3/page3',
                    routes: [
                        router_1.Route.of({
                            path: "/btb/tab3/page3",
                            build: function (router, route) {
                                return new page3_1.default(router, route);
                            },
                            headerBarParams: function () { return ({
                                visible: true
                            }); }
                        })
                    ]
                }),
                router_1.NativeStackRouter.of({
                    path: '/btb/tab4',
                    to: '/btb/tab4/page3',
                    routes: [
                        router_1.Route.of({
                            path: "/btb/tab4/page3",
                            build: function (router, route) {
                                return new page3_1.default(router, route);
                            },
                            headerBarParams: function () { return ({
                                visible: true
                            }); }
                        })
                    ]
                })
            ]
        }) || this;
    }
    $BottomTabBar.prototype.getRouter = function () {
        return this.bottomTabbarRouter;
    };
    return $BottomTabBar;
}(BottomTabbar_1.default));
exports.default = $BottomTabBar;
//# sourceMappingURL=tabbar.js.map