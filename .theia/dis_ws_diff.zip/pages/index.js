"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Page3 = exports.Page2 = exports.Page1 = void 0;
var page1_1 = require("./page1");
Object.defineProperty(exports, "Page1", { enumerable: true, get: function () { return __importDefault(page1_1).default; } });
var page2_1 = require("./page2");
Object.defineProperty(exports, "Page2", { enumerable: true, get: function () { return __importDefault(page2_1).default; } });
var page3_1 = require("./page3");
Object.defineProperty(exports, "Page3", { enumerable: true, get: function () { return __importDefault(page3_1).default; } });
//# sourceMappingURL=index.js.map