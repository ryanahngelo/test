"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var page1_1 = __importDefault(require("generated/pages/page1"));
var label_1 = __importDefault(require("@smartface/native/ui/label"));
var styling_context_1 = require("@smartface/styling-context");
var i18n_1 = require("@smartface/i18n");
var StyleableLabel = /** @class */ (function (_super) {
    __extends(StyleableLabel, _super);
    function StyleableLabel() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return StyleableLabel;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var Page1 = /** @class */ (function (_super) {
    __extends(Page1, _super);
    function Page1(router, route) {
        var _this = _super.call(this, {}) || this;
        _this.router = router;
        _this.route = route;
        _this.disposeables = [];
        _this.lbl = new StyleableLabel();
        console.log('[page1] constructor');
        return _this;
    }
    Page1.prototype.setTexts = function () {
        this.btnNext.text = i18n_1.i18n.instance.t('nextPage');
        this.lbl.text = i18n_1.i18n.instance.t('runtimeLabel');
    };
    /**
     * @event onShow
     * This event is called when a page appears on the screen (everytime).
     */
    Page1.prototype.onShow = function () {
        var _this = this;
        _super.prototype.onShow.call(this);
        console.log('[page1] onShow');
        this.disposeables.push(this.btnNext.on('press', function () {
            _this.router.push('page2', { message: i18n_1.i18n.instance.t('helloWorld') });
        }));
    };
    /**
     * @event onLoad
     * This event is called once when page is created.
     */
    Page1.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
        this.setTexts();
        console.log('[page1] onLoad');
        this.headerBar.leftItemEnabled = false;
        this.addChild(this.lbl, 'page1lbl1unique', 'sf-label', function (userProps) {
            return __assign({}, userProps);
        });
    };
    Page1.prototype.onHide = function () {
        this.dispose();
    };
    Page1.prototype.dispose = function () {
        this.disposeables.forEach(function (item) { return item(); });
    };
    return Page1;
}(page1_1.default));
exports.default = Page1;
//# sourceMappingURL=page1.js.map