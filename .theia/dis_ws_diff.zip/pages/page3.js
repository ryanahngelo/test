"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var page3_1 = __importDefault(require("generated/pages/page3"));
var mixins_1 = require("@smartface/mixins");
var Page3 = /** @class */ (function (_super) {
    __extends(Page3, _super);
    function Page3(router, route) {
        var _this = _super.call(this, {}) || this;
        _this.router = router;
        _this.route = route;
        _this.routeData = _this.route.getState().routeData;
        _this.btnDismiss.on('press', function () { return _this.router.goBack(); });
        return _this;
    }
    /**
     * @event onShow
     * This event is called when a page appears on the screen (everytime).
     */
    Page3.prototype.onShow = function () {
        _super.prototype.onShow.call(this);
        this.initDismissButton(this.router);
    };
    /**
     * @event onLoad
     * This event is called once when page is created.
     */
    Page3.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
    };
    return Page3;
}((0, mixins_1.withDismissAndBackButton)(page3_1.default)));
exports.default = Page3;
//# sourceMappingURL=page3.js.map