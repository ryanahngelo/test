"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var de_1 = __importDefault(require("./de"));
var en_1 = __importDefault(require("./en"));
var fi_1 = __importDefault(require("./fi"));
var tr_1 = __importDefault(require("./tr"));
var i18n_1 = require("@smartface/i18n");
var system_1 = __importDefault(require("@smartface/native/device/system"));
new i18n_1.i18n({
    lng: Device.language,
    debug: !!system_1.default.isEmulator,
    resources: {
        en: {
            translation: en_1.default
        },
        tr: {
            translation: tr_1.default
        },
        de: {
            translation: de_1.default
        },
        fi: {
            translation: fi_1.default
        }
    },
    fallbackLng: 'en'
});
//# sourceMappingURL=index.js.map